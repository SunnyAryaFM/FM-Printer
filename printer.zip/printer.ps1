# Define full paths
$javaPath = "C:\Users\Sunny\Downloads\out\java.exe"
$jarPath = "C:\Users\Sunny\Downloads\out\fm-print-service-1.0.0-SNAPSHOT.jar"
$ngrokPath = "C:\Users\Sunny\Downloads\out\ngrok.exe"
$configPath = "C:\Users\Sunny\AppData\Local\ngrok\ngrok.yml"

# Log files
$appOut = "C:\Users\Sunny\Downloads\out\app.log"
$appErr = "C:\Users\Sunny\Downloads\out\apperr.log"
$ngrokOut = "C:\Users\Sunny\Downloads\out\ngrokout.log"
$ngrokErr = "C:\Users\Sunny\Downloads\out\ngrokerr.log"

Start your Java app
Start-Process -FilePath $javaPath -ArgumentList "-jar", "`"$jarPath`"" `
    -RedirectStandardOutput $appOut -RedirectStandardError $appErr -WindowStyle Hidden

Start-Sleep -Seconds 5

# Ensure ngrok config exists (you’ve already run this once manually, so we skip it here)
if (-Not (Test-Path $configPath)) {
    Start-Process -FilePath $ngrokPath -ArgumentList "config", "add-authtoken", "2x5YUwMdLqALkD7KsPofhy26SiQ_6db1pdxKeF5CCw2zqABar" -Wait
}

# Start ngrok with reserved domain
Start-Process -FilePath $ngrokPath -ArgumentList "http", "--domain=emerging-emerging-hornet.ngrok-free.app", "http://127.0.0.1:9876" `
    -RedirectStandardOutput $ngrokOut -RedirectStandardError $ngrokErr -WindowStyle Hidden

Start-Sleep -Seconds 5
